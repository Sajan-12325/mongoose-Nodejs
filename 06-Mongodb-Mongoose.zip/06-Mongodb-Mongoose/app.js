var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');

var { engine } = require('express-handlebars');



var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');


var app = express();
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// view engine setup
app.engine('hbs', engine({ extname: 'hbs', defaultLayout: 'Layout', layoutsDir: __dirname + '/views/layouts' }));

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'hbs');

app.use(logger('dev'));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));


app.use('/', indexRouter);


// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler



app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(err.status || 500);
  res.render('error', { message: err.message });
});


module.exports = app;
