const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');

const url = 'mongodb://localhost:27017/test';
mongoose.connect(url)
.then(() => console.log("MongoDB Connected"))
.catch(err => console.error("MongoDB Connection Error:", err));


const Schema = mongoose.Schema;

const userDataSchema = new Schema({
  title: {type:String, required: true},
  content: String,
  author: String
},{collection: 'user-data'});

/*async function connectToDatabase() {
  try {await client.connect();
    console.log("Connected to database");
  } catch (err) {
    console.error(err);}}
// Calling the function to connect to database
connectToDatabase();*/


// Creating a model using above Schema
const UserData = mongoose.model('UserData', userDataSchema);


/* GET home page. */
router.get('/', (req, res, next) => {
  res.render('index');
});

router.get('/get-data', async (req, res, next) => {

    try {
      const docs = await UserData.find();
      res.render('index', { items: docs.map(doc => doc.toObject()) });
    } catch (err) {
      console.error(err);
      res.status(500).send("Error retrieving data.");
    }
  
});

// Insert data

router.post('/insert', async (req, res, next) => {
  console.log("Received data: ", req.body);
  const item = {
    title: req.body.title,
    content: req.body.content,
    author: req.body.author,
  };

  const data = new UserData(item);
  await data.save();

  res.redirect('/');   
});

const {ObjectId} = require('mongodb');

router.post('/update', async (req, res, next)=>{
  try{
    if (!req.body.id || !req.body.title || !req.body.content || !req.body.author) {
      return res.status(400).send("Please provide all fields.");
    }
  
    await UserData.findByIdAndUpdate(req.body.id, {
      title: req.body.title,
      content: req.body.content,
      author: req.body.author,
    });
    res.redirect('/');}
    

  catch (err) {
  console.error(err);
  res.status(500).send("Error updating data");}
});



router.post('/delete', async (req, res, next) => {
  try {
    const { id } = req.body;

    const doc = await UserData.findByIdAndDelete(id);
    if (!doc) {
      return res.status(404).send("Document not found");
    }
    res.redirect('/');

  } catch (err) {
    console.error(err);
    res.status(500).send("Error deleting data.");
  }

  
});



module.exports = router;
